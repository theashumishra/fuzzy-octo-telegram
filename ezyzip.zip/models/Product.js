// models/Product.js
const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    price: { type: Number, required: true },
    image: { type: String } // Optional, can store a URL or file path for the image
}, { timestamps: true });

module.exports = mongoose.model('Product', productSchema);
